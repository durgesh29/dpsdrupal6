NOTES
-----
CCK content type deployment has the same limitations that the Content Copy import function does - you can add new 
content types and add new fields to existing content types, but you can not modify existing fields in existing
content types. You also can not, for now, delete content types.

Content Type Deploy requires Drupal 5.11 or greater.
