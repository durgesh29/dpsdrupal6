<?php

/**
 * @file
 * This file is a dummy template.
 *
 * It serves as a reminder to theme authors that they must have a
 * uc_order.tpl.php file in their theme if they want to override the other
 * order templates.
 */
